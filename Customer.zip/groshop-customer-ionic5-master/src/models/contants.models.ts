export class Constants {
    static KEY_DEFAULT_LANGUAGE: string = 'ob_dl';
}